﻿var serviceRootUrl = "http://localhost:37534/api/Values/";

$(document).ready(onDocumentReady);

function onDocumentReady() {
    $("#btnGetProducts").on("click", onGetProducts);
    $("#noResult").hide();
    $("#tableProducts").hide();
}

function onGetProducts()
{
    var userId = $("#userId").val();
    if (isValid(userId)) {
        var serviceUrl = serviceRootUrl + userId;
        performGetRequest(serviceUrl, onGetProductsSuccess, onGetProductsError);
    }
}

function isValid(userId)
{
    if (userId.match(/([0-9])/)) {
        $("#validateError").hide()
        return true;
    }
    else {
        $("#validateError").show();
        return false;
    }
}

function performGetRequest(serviceUrl, onSuccess, onError, params) {
    $.ajax({
        url: serviceUrl,
        type: "GET",
        timeout: 5000,
        dataType: "json",
        success: onSuccess,
        error: onError,
        context: params
    });
}

function onGetProductsSuccess(responseObject) {
    if(responseObject!="")
    {
        $("#tableProducts").show();
        $("#noResult").hide();
        $("#tableProducts tbody").empty();

        for (var number = 0; number < responseObject.length ; number++) {
            var row = "<tr>" +
                           "<td>" + responseObject[number].UserId + "</td>" +
                           "<td>" + responseObject[number].ProductId + "</td>" +
                           "<td>" + responseObject[number].ProductDescription + "</td>" +
                           "<td>" + responseObject[number].TypeDescription + "</td>" +
                      "</tr>";
       
            $("#tableProducts").append(row);
        }
    }
    else
    {
        $("#tableProducts").hide();
        $("#noResult").show();
    }
}

function onGetProductsError(response) {
    alert("Error!");
}