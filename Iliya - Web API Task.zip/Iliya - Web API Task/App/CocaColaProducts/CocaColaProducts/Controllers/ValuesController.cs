﻿using CocaColaProducts.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CocaColaProducts.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values/id
        [HttpGet]
        public HttpResponseMessage Get(int id)
        {
            CocaColaEntities db = new CocaColaEntities();
            List<spGetProductsByUserId_Result> products = db.spGetProductsByUserId(id).ToList();

            List<ReturnDataModel> returnDataModels = new List<ReturnDataModel>();

            foreach (spGetProductsByUserId_Result product in products)
            {
                ReturnDataModel returnDataModel = new ReturnDataModel()
                {
                    UserId = product.UserId,
                    ProductId = product.ProductId,
                    ProductDescription = product.ProductDescription,
                    TypeDescription = product.TypeDescription
                };

                returnDataModels.Add(returnDataModel);
            }

            return Request.CreateResponse(HttpStatusCode.OK, returnDataModels);
        }
    }
}
