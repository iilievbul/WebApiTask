﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CocaColaProducts.Models
{
    public class ReturnDataModel
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public string ProductDescription { get; set; }
        public string TypeDescription { get; set; }
    }
}